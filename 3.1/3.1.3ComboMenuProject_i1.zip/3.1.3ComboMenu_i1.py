# Iteration 1
sandwich = input("What type of sandwich would you like? Chicken for $5.25, Beef for $6.25, Tofu for $5.75, or none? ")
print("You ordered a " + sandwich + " sandwich.")